import com.hivemq.client.mqtt.MqttClient;
import com.hivemq.client.mqtt.datatypes.MqttQos;
import com.hivemq.client.mqtt.mqtt5.Mqtt5AsyncClient;
import com.hivemq.client.mqtt.mqtt5.Mqtt5BlockingClient;
import com.hivemq.client.mqtt.mqtt5.message.connect.connack.Mqtt5ConnAck;
import com.hivemq.client.mqtt.mqtt5.message.publish.Mqtt5Publish;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class Redes {

    private static final String HOST     = "3c0e9445ee584760b0e9427ba2ba7022.s1.eu.hivemq.cloud";
    private static final int    PORT     = 8883;
    private static final String USERNAME = "MapaRuiz";
    private static final String PASSWORD = "Mapa123456*";
    private static final String TOPIC    = "CANAL";
    private static final float  UMBRAL   = 100.0f;

    static Long chatId = 6405088109L;
    static TelegramBot telegramBot = new TelegramBot();

    public void run() {
        try {
            // 1) Construye un cliente MQTT5 ASÍNCRONO con TLS y auto-reconexión
            Mqtt5AsyncClient client = MqttClient.builder()
                .useMqttVersion5()
                .serverHost(HOST)
                .serverPort(PORT)
                .sslWithDefaultConfig()                     // usa truststore JVM
                .identifier("java-async-" + UUID.randomUUID())
                .automaticReconnectWithDefaultConfig()
                .buildAsync();

            // 2) Conéctate con usuario/clave
            Mqtt5ConnAck connAck = client.connectWith()
                .simpleAuth()
                  .username(USERNAME)
                  .password(StandardCharsets.UTF_8.encode(PASSWORD))
                  .applySimpleAuth()
                .send()
                .get();    // bloquea hasta CONNECT
            System.out.println("🔌 MQTT Connected: " + connAck.getReasonCode());

            // 3) Suscríbete con callback
            client.subscribeWith()
                .topicFilter(TOPIC)
                .qos(MqttQos.AT_LEAST_ONCE)
                .callback((Mqtt5Publish publish) -> {
                    // decodifica el payload
                    ByteBuffer buf = publish.getPayload()
                                            .orElse(ByteBuffer.wrap(new byte[0]));
                    String payload = StandardCharsets.UTF_8.decode(buf).toString();
                    System.out.println("📥 Received on '"+ publish.getTopic() +"': " + payload);

                    // Lógica de umbral
                    try {
                        float val = Float.parseFloat(payload);
                        if (val > UMBRAL) {
                            client.publishWith()
                                .topic(TOPIC)
                                .qos(MqttQos.AT_LEAST_ONCE)
                                .payload(StandardCharsets.UTF_8.encode("Alerta"))
                                .send();
                            telegramBot.sendMessage(
                                telegramBot.generateSendMessage(chatId, "*Alerta* Niveles de metanol altos")
                            );
                            System.out.println("🚨 Alert sent");
                        }
                    } catch (NumberFormatException ignored) { }

                    // Lógica de servo
                    if ("SERVOACTIVADO".equalsIgnoreCase(payload)) {
                        try { Thread.sleep(5000); }
                        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                        client.publishWith()
                            .topic(TOPIC)
                            .qos(MqttQos.AT_LEAST_ONCE)
                            .payload(StandardCharsets.UTF_8.encode("Solucionado"))
                            .send();
                        telegramBot.sendMessage(
                            telegramBot.generateSendMessage(chatId, "Servomotor activado")
                        );
                        System.out.println("🔧 Solved published");
                    }
                })
                .send()
                .get();    // bloquea hasta SUBACK
            System.out.println("📰 Subscribed to: " + TOPIC);

            // 4) Publica tu mensaje inicial
            client.publishWith()
                .topic(TOPIC)
                .qos(MqttQos.AT_LEAST_ONCE)
                .payload(StandardCharsets.UTF_8.encode("Hello MQTT I'm JAVA"))
                .send()
                .get();
            System.out.println("✅ Initial message sent");

            // 5) Mantén viva la app (el hilo principal)
            Thread.currentThread().join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
